.. title:: clang-tidy - hicpp-use-auto
.. meta::
   :http-equiv=refresh: 5;URL=modernize-use-auto.html

hicpp-use-auto
==============

The `hicpp-use-auto` check is an alias, please see
`modernize-use-auto <modernize-use-auto.html>`_ for more information.
It enforces the `rule 7.1.8 <http://www.codingstandard.com/rule/7-1-8-use-auto-id-expr-when-declaring-a-variable-to-have-the-same-type-as-its-initializer-function-call/>`_.
