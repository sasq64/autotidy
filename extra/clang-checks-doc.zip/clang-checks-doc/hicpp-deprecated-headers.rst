.. title:: clang-tidy - hicpp-deprecated-headers
.. meta::
   :http-equiv=refresh: 5;URL=modernize-deprecated-headers.html

hicpp-deprecated-headers
========================

The `hicpp-deprecated-headers` check is an alias, please see
`modernize-deprecated-headers <modernize-deprecated-headers.html>`_
for more information.
It enforces the `rule 1.3.3 <http://www.codingstandard.com/rule/1-3-3-do-not-use-the-c-standard-library-h-headers/>`_.
