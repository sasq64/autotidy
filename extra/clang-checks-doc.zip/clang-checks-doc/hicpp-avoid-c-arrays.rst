.. title:: clang-tidy - hicpp-avoid-c-arrays
.. meta::
   :http-equiv=refresh: 5;URL=modernize-avoid-c-arrays.html

hicpp-avoid-c-arrays
====================

The hicpp-avoid-c-arrays check is an alias, please see
`modernize-avoid-c-arrays <modernize-avoid-c-arrays.html>`_
for more information.
