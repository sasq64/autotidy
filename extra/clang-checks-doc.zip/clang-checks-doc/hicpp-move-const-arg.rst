.. title:: clang-tidy - hicpp-move-const-arg
.. meta::
   :http-equiv=refresh: 5;URL=performance-move-const-arg.html

hicpp-move-const-arg
====================

The `hicpp-move-const-arg` check is an alias, please see
`performance-move-const-arg <performance-move-const-arg.html>`_ for more information.
It enforces the `rule 17.3.1 <http://www.codingstandard.com/rule/17-3-1-do-not-use-stdmove-on-objects-declared-with-const-or-const-type/>`_.
