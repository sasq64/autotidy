.. title:: clang-tidy - hicpp-uppercase-literal-suffix
.. meta::
   :http-equiv=refresh: 5;URL=readability-uppercase-literal-suffix.html

hicpp-uppercase-literal-suffix
==============================

The hicpp-uppercase-literal-suffix check is an alias, please see
`readability-uppercase-literal-suffix <readability-uppercase-literal-suffix.html>`_ for more information.
