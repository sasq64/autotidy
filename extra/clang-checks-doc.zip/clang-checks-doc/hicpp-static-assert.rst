.. title:: clang-tidy - hicpp-static-assert
.. meta::
   :http-equiv=refresh: 5;URL=misc-static-assert.html

hicpp-static-assert
===================

The `hicpp-static-assert` check is an alias, please see
`misc-static-assert <misc-static-assert.html>`_ for more information.
It enforces the `rule 7.1.10 <http://www.codingstandard.com/rule/6-1-1-enclose-the-body-of-a-selection-or-an-iteration-statement-in-a-compound-statement/>`_.
