.. title:: clang-tidy - hicpp-named-parameter
.. meta::
   :http-equiv=refresh: 5;URL=readability-named-parameter.html

hicpp-named-parameter
=====================

This check is an alias for `readability-named-parameter <readability-named-parameter.html>`_.

Implements `rule 8.2.1 <http://www.codingstandard.com/rule/8-2-1-make-parameter-names-absent-or-identical-in-all-declarations/>`_.
