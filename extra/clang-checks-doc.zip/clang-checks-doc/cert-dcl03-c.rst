.. title:: clang-tidy - cert-dcl03-c
.. meta::
   :http-equiv=refresh: 5;URL=misc-static-assert.html

cert-dcl03-c
============

The cert-dcl03-c check is an alias, please see
`misc-static-assert <misc-static-assert.html>`_ for more information.
