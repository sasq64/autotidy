.. title:: clang-tidy - google-default-arguments

google-default-arguments
========================

Checks that default arguments are not given for virtual methods.

See https://google.github.io/styleguide/cppguide.html#Default_Arguments
