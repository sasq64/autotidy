.. title:: clang-tidy - misc-unused-alias-decls

misc-unused-alias-decls
=======================


Finds unused namespace alias declarations.
