.. title:: clang-tidy - cert-err61-cpp
.. meta::
   :http-equiv=refresh: 5;URL=misc-throw-by-value-catch-by-reference.html

cert-err61-cpp
==============

The cert-err61-cpp check is an alias, please see
`misc-throw-by-value-catch-by-reference <misc-throw-by-value-catch-by-reference.html>`_
for more information.
