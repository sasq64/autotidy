.. title:: clang-tidy - hicpp-use-noexcept
.. meta::
   :http-equiv=refresh: 5;URL=modernize-use-noexcept.html

hicpp-use-noexcept
==================

The `hicpp-use-noexcept` check is an alias, please see
`modernize-use-noexcept <modernize-use-noexcept.html>`_ for more information.
It enforces the `rule 1.3.5 <http://www.codingstandard.com/rule/1-3-5-do-not-use-throw-exception-specifications/>`_.
