.. title:: clang-tidy - readability-redundant-string-cstr

readability-redundant-string-cstr
=================================


Finds unnecessary calls to ``std::string::c_str()`` and ``std::string::data()``.
