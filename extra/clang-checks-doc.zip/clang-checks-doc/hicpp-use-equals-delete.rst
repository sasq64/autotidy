.. title:: clang-tidy - hicpp-use-equals-delete
.. meta::
   :http-equiv=refresh: 5;URL=modernize-use-equals-delete.html

hicpp-use-equals-delete
=======================

This check is an alias for `modernize-use-equals-delete <modernize-use-equals-delete.html>`_.
Implements `rule 12.5.1 <http://www.codingstandard.com/rule/12-5-1-define-explicitly-default-or-delete-implicit-special-member-functions-of-concrete-classes/>`_ 
to explicitly default or delete special member functions.
