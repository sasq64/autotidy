.. title:: clang-tidy - cert-fio38-c
.. meta::
   :http-equiv=refresh: 5;URL=misc-non-copyable-objects.html

cert-fio38-c
============

The cert-fio38-c check is an alias, please see
`misc-non-copyable-objects <misc-non-copyable-objects.html>`_ for more
information.
