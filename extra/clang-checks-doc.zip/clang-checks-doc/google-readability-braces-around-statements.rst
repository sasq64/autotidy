.. title:: clang-tidy - google-readability-braces-around-statements
.. meta::
   :http-equiv=refresh: 5;URL=readability-braces-around-statements.html

google-readability-braces-around-statements
===========================================

The google-readability-braces-around-statements check is an alias, please see
`readability-braces-around-statements <readability-braces-around-statements.html>`_
for more information.
