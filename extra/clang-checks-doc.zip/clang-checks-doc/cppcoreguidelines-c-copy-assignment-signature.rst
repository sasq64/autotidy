.. title:: clang-tidy - cppcoreguidelines-c-copy-assignment-signature
.. meta::
   :http-equiv=refresh: 5;URL=misc-unconventional-assign-operator.html

cppcoreguidelines-c-copy-assignment-signature
=============================================

The cppcoreguidelines-c-copy-assignment-signature check is an alias, please see
`misc-unconventional-assign-operator <misc-unconventional-assign-operator.html>`_
for more information.
