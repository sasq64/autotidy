.. title:: clang-tidy - hicpp-use-nullptr
.. meta::
   :http-equiv=refresh: 5;URL=modernize-use-nullptr.html

hicpp-use-nullptr
=================

The `hicpp-use-nullptr` check is an alias, please see
`modernize-use-nullptr <modernize-use-nullptr.html>`_ for more information.
It enforces the `rule 2.5.3 <http://www.codingstandard.com/rule/2-5-3-use-nullptr-for-the-null-pointer-constant/>`_.
