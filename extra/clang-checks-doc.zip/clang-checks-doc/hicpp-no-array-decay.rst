.. title:: clang-tidy - hicpp-no-array-decay
.. meta::
   :http-equiv=refresh: 5;URL=cppcoreguidelines-pro-bounds-array-to-pointer-decay.html

hicpp-no-array-decay
====================

The `hicpp-no-array-decay` check is an alias, please see
`cppcoreguidelines-pro-bounds-array-to-pointer-decay <cppcoreguidelines-pro-bounds-array-to-pointer-decay.html>`_
for more information.
It enforces the `rule 4.1.1 <http://www.codingstandard.com/section/4-1-array-to-pointer-conversion/>`_.
