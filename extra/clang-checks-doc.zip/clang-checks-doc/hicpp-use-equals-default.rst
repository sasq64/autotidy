.. title:: clang-tidy - hicpp-use-equals-defaults
.. meta::
   :http-equiv=refresh: 5;URL=modernize-use-equals-default.html

hicpp-use-equals-default
========================

This check is an alias for `modernize-use-equals-default <modernize-use-equals-default.html>`_.
Implements `rule 12.5.1 <http://www.codingstandard.com/rule/12-5-1-define-explicitly-default-or-delete-implicit-special-member-functions-of-concrete-classes/>`_ to explicitly default special member functions.
