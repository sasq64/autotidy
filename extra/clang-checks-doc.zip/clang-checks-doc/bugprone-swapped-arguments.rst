.. title:: clang-tidy - bugprone-swapped-arguments

bugprone-swapped-arguments
==========================

Finds potentially swapped arguments by looking at implicit conversions.
