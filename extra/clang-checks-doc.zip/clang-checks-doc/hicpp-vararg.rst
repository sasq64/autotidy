.. title:: clang-tidy - hicpp-vararg
.. meta::
   :http-equiv=refresh: 5;URL=cppcoreguidelines-pro-type-vararg.html

hicpp-vararg
============

The `hicpp-vararg` check is an alias, please see
`cppcoreguidelines-pro-type-vararg <cppcoreguidelines-pro-type-vararg.html>`_
for more information.
It enforces the `rule 14.1.1 <http://www.codingstandard.com/section/14-1-template-declarations/>`_.
