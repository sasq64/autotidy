.. title:: clang-tidy - hicpp-new-delete-operators
.. meta::
   :http-equiv=refresh: 5;URL=misc-new-delete-overloads.html

hicpp-new-delete-operators
==========================

This check is an alias for `misc-new-delete-overloads <misc-new-delete-overloads.html>`_.
Implements `rule 12.3.1 <http://www.codingstandard.com/section/12-3-free-store/>`_ to ensure
the `new` and `delete` operators have the correct signature.
