:orphan:

.. title:: clang-tidy - performance-implicit-cast-in-loop
.. meta::
   :http-equiv=refresh: 5;URL=performance-implicit-conversion-in-loop.html

performance-implicit-cast-in-loop
=================================

This check has been renamed to `performance-implicit-conversion-in-loop
<performance-implicit-conversion-in-loop.html>`_.

