.. title:: clang-tidy - cppcoreguidelines-non-private-member-variables-in-classes
.. meta::
   :http-equiv=refresh: 5;URL=misc-non-private-member-variables-in-classes.html

cppcoreguidelines-non-private-member-variables-in-classes
=========================================================

The cppcoreguidelines-non-private-member-variables-in-classes check is an alias,
please see
`misc-non-private-member-variables-in-classes <misc-non-private-member-variables-in-classes.html>`_
for more information.
