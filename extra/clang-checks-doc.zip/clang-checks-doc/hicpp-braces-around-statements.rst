.. title:: clang-tidy - hicpp-braces-around-statements
.. meta::
   :http-equiv=refresh: 5;URL=readability-braces-around-statements.html

hicpp-braces-around-statements
==============================

The `hicpp-braces-around-statements` check is an alias, please see
`readability-braces-around-statements <readability-braces-around-statements.html>`_
for more information.
It enforces the `rule 6.1.1 <http://www.codingstandard.com/rule/6-1-1-enclose-the-body-of-a-selection-or-an-iteration-statement-in-a-compound-statement/>`_.
