.. title:: clang-tidy - cppcoreguidelines-avoid-c-arrays
.. meta::
   :http-equiv=refresh: 5;URL=modernize-avoid-c-arrays.html

cppcoreguidelines-avoid-c-arrays
================================

The cppcoreguidelines-avoid-c-arrays check is an alias, please see
`modernize-avoid-c-arrays <modernize-avoid-c-arrays.html>`_
for more information.
