.. title:: clang-tidy - hicpp-no-malloc
.. meta::
   :http-equiv=refresh: 5;URL=cppcoreguidelines-no-malloc.html

hicpp-no-malloc
===============

The `hicpp-no-malloc` check is an alias, please see
`cppcoreguidelines-no-malloc <cppcoreguidelines-no-malloc.html>`_
for more information.
It enforces the `rule 5.3.2 <http://www.codingstandard.com/rule/5-3-2-allocate-memory-using-new-and-release-it-using-delete/>`_.
