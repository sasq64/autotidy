.. title:: clang-tidy - hicpp-use-override
.. meta::
   :http-equiv=refresh: 5;URL=modernize-use-override.html

hicpp-use-override
==================

This check is an alias for `modernize-use-override <modernize-use-override.html>`_.
Implements `rule 10.2.1 <http://www.codingstandard.com/section/10-2-virtual-functions/>`_ to 
declare a virtual function `override` when overriding.
