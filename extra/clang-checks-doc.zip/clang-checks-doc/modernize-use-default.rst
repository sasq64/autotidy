:orphan:

.. title:: clang-tidy - modernize-use-default
.. meta::
   :http-equiv=refresh: 5;URL=modernize-use-equals-default.html

modernize-use-default
=====================

This check has been renamed to
`modernize-use-equals-default <modernize-use-equals-default.html>`_.
