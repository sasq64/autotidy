.. title:: clang-tidy - google-readability-namespace-comments
.. meta::
   :http-equiv=refresh: 5;URL=llvm-namespace-comment.html

google-readability-namespace-comments
=====================================

The google-readability-namespace-comments check is an alias, please see
`llvm-namespace-comment <llvm-namespace-comment.html>`_ for more information.
