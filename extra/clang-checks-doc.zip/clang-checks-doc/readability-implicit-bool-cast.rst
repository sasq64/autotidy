:orphan:

.. title:: clang-tidy - readability-implicit-bool-cast
.. meta::
   :http-equiv=refresh: 5;URL=readability-implicit-bool-conversion.html

readability-implicit-bool-cast
==============================

This check has been renamed to `readability-implicit-bool-conversion
<readability-implicit-bool-conversion.html>`_.
