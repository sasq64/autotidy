.. title:: clang-tidy - cert-dcl59-cpp
.. meta::
   :http-equiv=refresh: 5;URL=google-build-namespaces.html

cert-dcl59-cpp
==============

The cert-dcl59-cpp check is an alias, please see
`google-build-namespaces <google-build-namespaces.html>`_ for more information.
