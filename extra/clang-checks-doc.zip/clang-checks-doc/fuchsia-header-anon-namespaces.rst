.. title:: clang-tidy - fuchsia-header-anon-namespaces
.. meta::
   :http-equiv=refresh: 5;URL=google-build-namespaces.html

fuchsia-header-anon-namespaces
==============================

The fuchsia-header-anon-namespaces check is an alias, please see
`google-build-namespace <google-build-namespaces.html>`_
for more information.
