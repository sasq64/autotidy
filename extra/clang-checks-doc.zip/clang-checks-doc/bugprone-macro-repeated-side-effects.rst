.. title:: clang-tidy - bugprone-macro-repeated-side-effects

bugprone-macro-repeated-side-effects
====================================


Checks for repeated argument with side effects in macros.
