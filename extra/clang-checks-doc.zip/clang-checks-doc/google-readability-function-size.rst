.. title:: clang-tidy - google-readability-function-size
.. meta::
   :http-equiv=refresh: 5;URL=readability-function-size.html

google-readability-function-size
================================

The google-readability-function-size check is an alias, please see
`readability-function-size <readability-function-size.html>`_ for more
information.
