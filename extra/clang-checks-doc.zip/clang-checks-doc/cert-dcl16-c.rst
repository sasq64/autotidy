.. title:: clang-tidy - cert-dcl16-c
.. meta::
   :http-equiv=refresh: 5;URL=readability-uppercase-literal-suffix.html

cert-dcl16-c
============

The cert-dcl16-c check is an alias, please see
`readability-uppercase-literal-suffix <readability-uppercase-literal-suffix.html>`_ for more information.
