.. title:: clang-tidy - cert-msc32-c
.. meta::
   :http-equiv=refresh: 5;URL=cert-msc51-cpp.html

cert-msc32-c
============

The cert-msc32-c check is an alias, please see
`cert-msc51-cpp <cert-msc51-cpp.html>`_ for more information.
