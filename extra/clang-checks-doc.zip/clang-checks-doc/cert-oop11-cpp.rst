.. title:: clang-tidy - cert-oop11-cpp
.. meta::
   :http-equiv=refresh: 5;URL=performance-move-constructor-init.html

cert-oop11-cpp
==============

The cert-oop11-cpp check is an alias, please see
`performance-move-constructor-init <performance-move-constructor-init.html>`_
for more information.
