.. title:: clang-tidy - llvm-include-order

llvm-include-order
==================


Checks the correct order of ``#includes``.

See http://llvm.org/docs/CodingStandards.html#include-style
