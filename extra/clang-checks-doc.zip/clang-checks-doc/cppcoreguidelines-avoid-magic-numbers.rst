.. title:: clang-tidy - cppcoreguidelines-avoid-magic-numbers
.. meta::
   :http-equiv=refresh: 5;URL=readability-magic-numbers.html

cppcoreguidelines-avoid-magic-numbers
=====================================

The cppcoreguidelines-avoid-magic-numbers check is an alias, please see
`readability-magic-numbers <readability-magic-numbers.html>`_
for more information.
