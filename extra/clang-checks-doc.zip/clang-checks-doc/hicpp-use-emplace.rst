.. title:: clang-tidy - hicpp-use-emplace
.. meta::
   :http-equiv=refresh: 5;URL=modernize-use-emplace.html

hicpp-use-emplace
=================

The `hicpp-use-emplace` check is an alias, please see
`modernize-use-emplace <modernize-use-emplace.html>`_ for more information.
It enforces the `rule 17.4.2 <http://www.codingstandard.com/rule/17-4-2-use-api-calls-that-construct-objects-in-place/>`_.
